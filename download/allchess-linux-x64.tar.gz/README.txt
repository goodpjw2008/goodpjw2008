AllChess  (allchess)
Chess for everyone - runs on low-spec PCs with no internet connection

  # Nothing to install. Just run allchess.
    A browser window opens with the chess board.

    [ On macOS ] Double-click allchess.command instead.
    The window stays open on error, so you can read the message.
    If you get an "unidentified developer" warning, go to
    System Settings > Privacy & Security and click "Open Anyway" once.

  # This single file is everything.
    The chess engine, the neural-network weights and the board UI are all
    inside it. No internet, no Python, no installer needed.

  # In [Settings] on screen you can pick one of two modes.
      High   PST + NNUE hybrid   Default. Strongest overall
      Low    PST only            For very slow PCs

  # Command-line options (you do not need these)
      --movetime 2000   Time per move for the engine, in milliseconds
      --no-nnue         Start in Low mode
      --uci             UCI mode, for chess GUIs
      --help            Show help

  # The board is served only inside this PC (127.0.0.1). Nothing outside can reach it.

  # License     : GPL-3.0-or-later. You are free to redistribute it.
                  See LICENSE.txt and licenses/ for details.
  # Source code : This executable does not contain the source.
                  Get allchess-src.tar.gz from the same release page.
                  https://github.com/goodpjw2008/allchess/releases
  # Author      : goodpjw2008@gmail.com
